export interface CampoGenerico {
  tipo: string;
  valor: any;
}
